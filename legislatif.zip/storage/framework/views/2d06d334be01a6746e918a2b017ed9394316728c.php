

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">
                        Tambah Data TPS
                    </div>
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('tps.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="nomor_tps">Nomor TPS</label>
                                <input type="text" name="nomor_tps" class="form-control" id="nomor_tps">
                            </div>
                            <div class="form-group">
                                <label for="nama_saksi">Nama Saksi</label>
                                <input type="text" name="nama_saksi" class="form-control" id="nama_saksi">
                            </div>
                            <div class="form-group">
                                <label for="alamat_tps_id">Alamat TPS</label>
                                <select name="alamat_tps_id" class="form-control" id="alamat_tps_id">
                                    <?php $__currentLoopData = $alamat_tps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $at): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($at->id); ?>"><?php echo e($at->alamat_tps); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\legislatif\resources\views/data_tps/create_data_tps.blade.php ENDPATH**/ ?>