
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    
                    <div class="card-header">Daftar TPS</div>
                    <a href="<?php echo e(route('tps.create')); ?>" class="btn btn-primary float-right">Tambah Data</a>
                    <div class="card-body">
                    

                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nomor TPS</th>
                                    <th scope="col">Nama Saksi</th>
                                    <th scope="col">Alamat TPS</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($tps->nomor_tps); ?></td>
                                        <td><?php echo e($tps->nama_saksi); ?></td>
                                        <td><?php echo e($tps->alamatTps->alamat_tps); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('tps.show', $tps->id)); ?>" class="btn btn-primary">Lihat</a>
                                            <a href="<?php echo e(route('tps.edit', $tps->id)); ?>" class="btn btn-warning">Edit</a>
                                            <form action="<?php echo e(route('tps.destroy', $tps->id)); ?>" method="POST" style="display: inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah anda yakin ingin menghapus TPS ini?')">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\legislatif\resources\views/data_tps/show_data_tps.blade.php ENDPATH**/ ?>