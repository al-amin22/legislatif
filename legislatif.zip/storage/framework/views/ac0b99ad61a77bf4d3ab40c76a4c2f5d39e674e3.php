

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Detail Alamat TPS</h4>
                        <a href="<?php echo e(route('alamat-tps.index')); ?>" class="btn btn-primary float-right">Kembali</a>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Alamat TPS:</h5>
                                <p><?php echo e($alamatTps->alamat_tps); ?></p>
                            </div>
                        </div>
                        <hr>
                        <h5>Daftar TPS:</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead class=" text-primary">
                                    <tr>
                                        <th>No.</th>
                                        <th>Nomor TPS</th>
                                        <th>Jumlah Pemilih</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $alamatTps->tps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key+1); ?></td>
                                            <td><?php echo e($tps->nomor_tps); ?></td>
                                            <td><?php echo e($tps->pemilih_count); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('tps.show', $tps->id)); ?>" class="btn btn-info">Lihat</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\legislatif\resources\views/data_alamat_tps/detail_data_alamat_tps.blade.php ENDPATH**/ ?>