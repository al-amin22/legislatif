

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Detail TPS</h1>

        <?php if(!$tps): ?>
            <p>Data kosong</p>
        <?php else: ?>
            <div class="card">
                <div class="card-header">
                    Nomor TPS: <?php echo e($tps->nomor_tps); ?>

                </div>
                <div class="card-body">
                    <h5 class="card-title">Alamat TPS:</h5>
                    <p class="card-text"><?php echo e($tps->alamatTps->alamat_tps); ?></p>
                </div>
            </div>

            <br>

            <h5>Daftar Pemilih:</h5>

            <?php if($tps->pemilih->count() == 0): ?>
            <div class="alert alert-danger">
                                Data Kosong
                            </div>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">NIK Pemilih</th>
                            <th scope="col">Nama Pemilih</th>
                            <th scope="col">Alamat Pemilih</th>
                            <th scope="col">RT Pemilih</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tps->pemilih; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pemilih): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($index + 1); ?></th>
                                <td><?php echo e($pemilih->nik_pemilih); ?></td>
                                <td><?php echo e($pemilih->nama_pemilih); ?></td>
                                <td><?php echo e($pemilih->alamat_pemilih); ?></td>
                                <td><?php echo e($pemilih->rt_pemilih); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u472680438/domains/creative-ku.com/public_html/legislatif/resources/views/data_tps/detail_data_tps.blade.php ENDPATH**/ ?>