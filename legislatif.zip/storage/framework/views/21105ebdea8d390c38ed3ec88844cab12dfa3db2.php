

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">Edit Data Pemilih</div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('pemilih.update', $pemilih->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="form-group">
                                <label for="nik_pemilih">NIK Pemilih</label>
                                <input type="text" class="form-control" id="nik_pemilih" name="nik_pemilih" value="<?php echo e($pemilih->nik_pemilih); ?>">
                            </div>

                            <div class="form-group">
                                <label for="nama_pemilih">Nama Pemilih</label>
                                <input type="text" class="form-control" id="nama_pemilih" name="nama_pemilih" value="<?php echo e($pemilih->nama_pemilih); ?>">
                            </div>

                            <div class="form-group">
                                <label for="alamat_pemilih">Alamat Pemilih</label>
                                <input type="text" class="form-control" id="alamat_pemilih" name="alamat_pemilih" value="<?php echo e($pemilih->alamat_pemilih); ?>">
                            </div>

                            <div class="form-group">
                                <label for="rt_pemilih">RT Pemilih</label>
                                <input type="text" class="form-control" id="rt_pemilih" name="rt_pemilih" value="<?php echo e($pemilih->rt_pemilih); ?>">
                            </div>

                            <div class="form-group">
                                <label for="id_tps">TPS</label>
                                <select name="alamat_tps_id" id="alamat_tps_id">
                                    <option value="">-- Pilih Alamat TPS --</option>
                                    <?php $__currentLoopData = $alamat_tps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $at): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($at->id); ?>"><?php echo e($at->alamat_tps); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['id_tps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="nomor_tps">Nomor TPS</label>
                                <select name="nomor_tps" id="nomor_tps">
                                    <option value="">-- Pilih Nomor TPS --</option>
                                </select>
                            </div>
                            <div class="form-group mb-0">
                                <button type="submit" class="btn btn-primary">
                                    Simpan
                                </button>
                                <a href="<?php echo e(route('pemilih.index')); ?>" class="btn btn-secondary">
                                    Kembali
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#alamat_tps_id').on('change', function() {
        var alamat_tps_id = $(this).val();
        if (alamat_tps_id) {
            $.ajax({
                url: '/tps/getNomorTps/' + alamat_tps_id,
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    $('#nomor_tps').empty();
                    $('#nomor_tps').append('<option value="">-- Pilih Nomor TPS --</option>');
                    $.each(data, function(key, value) {
                        $('#nomor_tps').append('<option value="' + value.id + '">' + value.nomor_tps + '</option>');
                    });
                }
            });
        } else {
            $('#nomor_tps').empty();
            $('#nomor_tps').append('<option value="">-- Pilih Nomor TPS --</option>');
        }
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\legislatif\resources\views/data_pemilih/edit_data_pemilih.blade.php ENDPATH**/ ?>