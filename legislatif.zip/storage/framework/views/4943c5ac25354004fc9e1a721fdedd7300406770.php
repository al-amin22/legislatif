<!-- resources/views/auth/login.blade.php -->



<?php $__env->startSection('content'); ?>
<!-- resources/views/auth/login.blade.php -->
<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
    <input type="password" name="password" required>
    <input type="submit" value="Login">
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\legislatif\resources\views/auth/login.blade.php ENDPATH**/ ?>