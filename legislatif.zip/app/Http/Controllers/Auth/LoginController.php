<?php

namespace App\Http\Controllers\Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    use AuthenticatesUsers;

    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $this->validateLogin($request);

        if ($this->attemptLogin($request)) {
            return $this->sendLoginResponse($request);
        }

        throw ValidationException::withMessages([
            $this->username() => [trans('auth.failed')],
        ]);
    }

    protected function redirectTo()
    {
        $user = Auth::user();

        if ($user->isAdmin()) {
            return '/grafik'; // ganti dengan URL atau route untuk halaman admin
        } elseif ($user->isUser()) {
            return '/grafik'; // ganti dengan URL atau route untuk halaman user
        }

        return '/';
    }
}
