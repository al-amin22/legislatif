<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class AuthController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.login');
    }
    protected function authenticated(Request $request, $user)
    {
        if ($user->role == 0) {
            return redirect()->route('home'); // Redirect ke halaman home jika role adalah 0 (misalnya role pengguna biasa)
        } elseif ($user->role == 1) {
            return redirect()->route('admin.dashboard'); // Redirect ke halaman admin jika role adalah 1 (misalnya role admin)
        } else {
            return redirect()->route('login'); // Redirect ke halaman login jika role tidak valid
        }
    }
    
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'role' => 0, // Mengatur role pengguna menjadi 0 (default)
        ]);
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('login');
    }
}
