<!-- resources/views/auth/login.blade.php -->

@extends('layouts.app')

@section('content')
<!-- resources/views/auth/login.blade.php -->
<form method="POST" action="{{ route('login') }}">
    @csrf
    <input type="email" name="email" value="{{ old('email') }}" required autofocus>
    <input type="password" name="password" required>
    <input type="submit" value="Login">
</form>

@endsection
